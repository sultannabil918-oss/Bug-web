const officialTokenValue = "8762129106:AAHn9LalyIqkSz55WK-55gMgRDe2X7HGoXg";
module.exports = {
    officialToken: officialTokenValue
};