module.exports = {
  tokens: "8280302493:AAFxXvJ_RX0rja__t7d_mHqVVEJ8Wvpzxp8", 
  owner: "7846858206", 
  port: "4001", // Ini Wajib Jangan Diubah
  ipvps: "vixzzoffecial.hostingvvip.web.id" // Jangan Diubah Nanti Eror!!
};